package com.safeanchor;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/** Hiệu ứng kiểu PURXIY: vòng nhảy / ripple khi đánh, Block Outline trượt mượt, hoạt ảnh đặt block, CPS, combo. */
public class Fx {
    static class Ring { Vec3d pos; long t0; double maxR; int ticks, rgb; }
    static class Pl { BlockPos pos; long t0; }
    static final List<Ring> rings = new ArrayList<>();
    static final List<Pl> places = new ArrayList<>();
    static boolean prevGround = true, pL, pR;
    static Box glide;
    static final ArrayDeque<Long> cl = new ArrayDeque<>(), cr = new ArrayDeque<>();
    public static int combo;
    static long lastHit;
    static Entity lastTarget; static long lastTargetMs;
    static class Tile { Vec3d pos; long t0; }
    static final List<Tile> tiles = new ArrayList<>();
    static double prevFall;
    public static int totems, pops, prevTotems = -1;
    static final java.util.Random RND = new java.util.Random();

    static Ring ring(Vec3d pos, double maxR, int ticks, int rgb) {
        Ring r = new Ring(); r.pos = pos; r.maxR = maxR; r.ticks = Math.max(4, ticks); r.rgb = rgb;
        r.t0 = MinecraftClient.getInstance().world.getTime(); return r;
    }

    public static void onHit(Entity e) {
        Config c = Config.I;
        lastHit = System.currentTimeMillis(); combo++;
        lastTarget = e; lastTargetMs = lastHit;
        var mc0 = MinecraftClient.getInstance();
        if (c.hitSplash && mc0.world != null) {
            for (int i = 0; i < 26; i++) {
                double rx = RND.nextGaussian() * 0.15, ry = RND.nextDouble() * 0.2, rz = RND.nextGaussian() * 0.15;
                mc0.world.addParticle(new DustParticleEffect(c.chroma ? Util.chroma(i * 0.04) : c.splashColor, 1.3f),
                        e.getX(), e.getY() + e.getHeight() * 0.5, e.getZ(), rx, ry, rz);
            }
        }
        if (c.ringHit && MinecraftClient.getInstance().world != null) rings.add(ring(e.getPos(), 1.6, 12, c.ringHitColor));
    }

    public static void onPlace(BlockPos p) {
        if (!Config.I.placeAnimOn || MinecraftClient.getInstance().world == null) return;
        Pl x = new Pl(); x.pos = p; x.t0 = MinecraftClient.getInstance().world.getTime(); places.add(x);
    }

    static int cps(ArrayDeque<Long> d) {
        long n = System.currentTimeMillis();
        while (!d.isEmpty() && n - d.peekFirst() > 1000) d.pollFirst();
        return d.size();
    }
    public static int cpsL() { return cps(cl); }
    public static int cpsR() { return cps(cr); }

    public static void tick(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player;
        if (p == null || mc.world == null) return;
        long now = System.currentTimeMillis();
        if (mc.currentScreen == null) {
            long win = mc.getWindow().getHandle();
            boolean l = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
            boolean r = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
            if (l && !pL) cl.addLast(now);
            if (r && !pR) cr.addLast(now);
            pL = l; pR = r;
        }
        if (combo > 0 && (now - lastHit > 3000 || p.hurtTime > 0)) combo = 0;
        // totem
        int tc = 0;
        for (int i = 0; i < p.getInventory().size(); i++) { ItemStack st = p.getInventory().getStack(i); if (st.isOf(Items.TOTEM_OF_UNDYING)) tc += st.getCount(); }
        if (prevTotems >= 0 && tc < prevTotems) pops += prevTotems - tc;
        prevTotems = tc; totems = tc;
        // afterglow: mục tiêu vừa đánh đã chết -> hạt bay lên
        if (lastTarget != null) {
            if (now - lastTargetMs > 8000) lastTarget = null;
            else if (lastTarget instanceof LivingEntity le && (le.isDead() || le.getHealth() <= 0f)) {
                if (c.afterglow) for (int i = 0; i < 70; i++) {
                    double ang = RND.nextDouble() * Math.PI * 2, r = RND.nextDouble() * 0.5;
                    mc.world.addParticle(i % 3 == 0 ? ParticleTypes.END_ROD : new DustParticleEffect(c.chroma ? Util.chroma(i * 0.03) : c.splashColor, 1.0f),
                            le.getX() + Math.cos(ang) * r, le.getY() + RND.nextDouble() * le.getHeight(), le.getZ() + Math.sin(ang) * r, 0, 0.05 + RND.nextDouble() * 0.05, 0);
                }
                lastTarget = null;
            }
        }
        boolean g = p.isOnGround();
        if (c.ringJump && prevGround && !g && p.getVelocity().y > 0.1) rings.add(ring(p.getPos(), c.ringSize, c.ringTicks, c.ringColor));
        if (!g) prevFall = (double) p.fallDistance;
        if (!prevGround && g && c.tileOn && prevFall >= 1.0) { Tile t = new Tile(); t.pos = p.getPos(); t.t0 = mc.world.getTime(); tiles.add(t); }
        prevGround = g;
        long wt = mc.world.getTime();
        rings.removeIf(r -> wt - r.t0 > r.ticks);
        tiles.removeIf(q -> wt - q.t0 > 14);
        places.removeIf(q -> wt - q.t0 > Math.max(3, c.placeTicks));
    }

    static Box lerpBox(Box a, Box b, double f) {
        return new Box(a.minX + (b.minX - a.minX) * f, a.minY + (b.minY - a.minY) * f, a.minZ + (b.minZ - a.minZ) * f,
                a.maxX + (b.maxX - a.maxX) * f, a.maxY + (b.maxY - a.maxY) * f, a.maxZ + (b.maxZ - a.maxZ) * f);
    }

    static void circle(BufferBuilder lb, Matrix4f m, Vec3d c, double r, int rgb, int a) {
        int n = 44;
        for (int i = 0; i < n; i++) {
            double a0 = Math.PI * 2 * i / n, a1 = Math.PI * 2 * (i + 1) / n;
            Esp.line(lb, m, new Vec3d(c.x + Math.cos(a0) * r, c.y + 0.03, c.z + Math.sin(a0) * r),
                    new Vec3d(c.x + Math.cos(a1) * r, c.y + 0.03, c.z + Math.sin(a1) * r), rgb, a);
        }
    }

    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance(); Config c = Config.I;
        if (!c.enabled || mc.player == null || mc.world == null) return;
        if (rings.isEmpty() && places.isEmpty() && tiles.isEmpty() && !c.glideOn && !c.targetEsp && !c.radiance && !c.gridOn) return;
        MatrixStack ms = ctx.matrixStack();
        if (ms == null) return;
        Vec3d cp = ctx.camera().getPos();
        float td = ctx.tickCounter().getTickDelta(false);
        double now = mc.world.getTime() + td;
        Matrix4f m = ms.peek().getPositionMatrix();

        // block đang nhìn: khung trượt mượt
        Box gb = null;
        if (c.glideOn) {
            if (mc.crosshairTarget instanceof BlockHitResult bh && bh.getType() == HitResult.Type.BLOCK) {
                BlockPos bp = bh.getBlockPos();
                var sh = mc.world.getBlockState(bp).getOutlineShape(mc.world, bp);
                Box t = (sh.isEmpty() ? new Box(bp) : sh.getBoundingBox().offset(bp)).expand(0.003);
                glide = (glide == null || glide.getCenter().distanceTo(t.getCenter()) > 8) ? t : lerpBox(glide, t, Math.min(1.0, c.glideSpeed / 100.0));
                gb = glide.offset(-cp.x, -cp.y, -cp.z);
            } else glide = null;
        }
        int gcol = c.chroma ? Util.chroma(0) : c.glideColor;

        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        // lượt 1: phần tô
        int nq = 0;
        BufferBuilder qb = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        if (gb != null) { Esp.fill(qb, m, gb, gcol, 45); nq++; }
        for (Pl q : places) {
            double f = Math.min(1.0, (now - q.t0) / Math.max(3, c.placeTicks));
            double s = 0.15 + 0.85 * f;
            Vec3d ce = Vec3d.ofCenter(q.pos).subtract(cp);
            Box b = new Box(ce.x - 0.5 * s, ce.y - 0.5 * s, ce.z - 0.5 * s, ce.x + 0.5 * s, ce.y + 0.5 * s, ce.z + 0.5 * s);
            Esp.fill(qb, m, b, c.chroma ? Util.chroma(f) : c.placeColor, (int) (170 * (1 - f)) + 10); nq++;
        }
        if (c.radiance) {
            double pulse = 0.04 * Math.sin(now * 0.3);
            int k = 0;
            for (PlayerEntity o : mc.world.getPlayers()) {
                if (o == mc.player || o.isSpectator() || o.squaredDistanceTo(mc.player) > 48 * 48) continue;
                Vec3d lp = o.getLerpedPos(td);
                Box bb0 = o.getBoundingBox().offset(lp.subtract(o.getPos()).subtract(cp));
                int col = c.chroma ? Util.chroma(k++ * 0.1) : c.radianceColor;
                Esp.fill(qb, m, bb0.expand(0.05 + pulse), col, 55);
                Esp.fill(qb, m, bb0.expand(0.13 + pulse * 2), col, 28);
                nq++;
            }
        }
        for (Tile t : tiles) {
            double f = (now - t.t0) / 14.0; if (f >= 1) continue;
            int R = Math.max(2, c.tileRadius);
            double front = f * R, y0 = t.pos.y + 0.01 - cp.y;
            int bx = (int) Math.floor(t.pos.x), bz = (int) Math.floor(t.pos.z);
            for (int dx = -R; dx <= R; dx++) for (int dz = -R; dz <= R; dz++) {
                double d = Math.hypot(dx, dz), diff = Math.abs(d - front);
                if (diff >= 1.3) continue;
                int a = (int) (150 * (1 - diff / 1.3) * (1 - f * 0.7));
                if (a < 8) continue;
                double x0 = bx + dx - cp.x, z0 = bz + dz - cp.z;
                Esp.fill(qb, m, new Box(x0 + 0.04, y0, z0 + 0.04, x0 + 0.96, y0 + 0.03, z0 + 0.96), c.chroma ? Util.chroma(d * 0.05) : c.tileColor, a);
                nq++;
            }
        }
        if (nq > 0) BufferRenderer.drawWithGlobalProgram(qb.end());

        // lượt 2: đường viền + vòng
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.lineWidth(2.5f);
        int nl = 0;
        BufferBuilder lb = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        if (gb != null) { Esp.outline(lb, m, gb, gcol); nl++; }
        for (Pl q : places) {
            double f = Math.min(1.0, (now - q.t0) / Math.max(3, c.placeTicks));
            double s = 0.15 + 0.85 * f;
            Vec3d ce = Vec3d.ofCenter(q.pos).subtract(cp);
            Esp.outline(lb, m, new Box(ce.x - 0.5 * s, ce.y - 0.5 * s, ce.z - 0.5 * s, ce.x + 0.5 * s, ce.y + 0.5 * s, ce.z + 0.5 * s), c.chroma ? Util.chroma(f) : c.placeColor); nl++;
        }
        for (Ring r : rings) {
            double f = (now - r.t0) / r.ticks;
            if (f >= 1) continue;
            double rad = f * r.maxR;
            int a = (int) (255 * (1 - f));
            int col = c.chroma ? Util.chroma(f) : r.rgb;
            Vec3d ctr = r.pos.subtract(cp);
            for (int k = 0; k < 3; k++) { circle(lb, m, ctr, rad * (1 - 0.18 * k), col, (int) (a * (1 - 0.3 * k))); nl++; }
        }
        if (c.targetEsp) {
            Entity tg = lastTarget != null && System.currentTimeMillis() - lastTargetMs < 6000 && lastTarget.isAlive() ? lastTarget
                    : (mc.targetedEntity instanceof LivingEntity ? mc.targetedEntity : null);
            if (tg != null) {
                Vec3d lp = tg.getLerpedPos(td).subtract(cp);
                double hh = 0.5 + 0.5 * Math.sin(now * 0.25);
                int col = c.chroma ? Util.chroma(now * 0.01) : c.targetColor;
                circle(lb, m, new Vec3d(lp.x, lp.y + hh * tg.getHeight() - 0.03, lp.z), tg.getWidth() * 0.9, col, 255);
                circle(lb, m, new Vec3d(lp.x, lp.y + (1 - hh) * tg.getHeight() - 0.03, lp.z), tg.getWidth() * 0.7, col, 160);
                nl++;
            }
        }
        if (c.gridOn) {
            int R = Math.max(3, c.gridRadius);
            double gy = Math.floor(mc.player.getY() + 0.001) + 0.01 - cp.y;
            int x0 = (int) Math.floor(mc.player.getX()), z0 = (int) Math.floor(mc.player.getZ());
            for (int i = -R; i <= R; i++) for (int j = -R; j < R; j++) {
                double d1 = Math.hypot(i + 0.5, j + 0.5), d2 = Math.hypot(j + 0.5, i + 0.5);
                int col = c.chroma ? Util.chroma((i + j) * 0.02) : c.gridColor;
                int a1 = (int) (200 * Math.max(0, 1 - d1 / R)), a2 = a1;
                if (a1 > 6) {
                    Esp.line(lb, m, new Vec3d(x0 + i - cp.x, gy, z0 + j - cp.z), new Vec3d(x0 + i - cp.x, gy, z0 + j + 1 - cp.z), col, a1);
                    Esp.line(lb, m, new Vec3d(x0 + j - cp.x, gy, z0 + i - cp.z), new Vec3d(x0 + j + 1 - cp.x, gy, z0 + i - cp.z), col, a2);
                    nl++;
                }
            }
        }
        if (nl > 0) BufferRenderer.drawWithGlobalProgram(lb.end());
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }
}

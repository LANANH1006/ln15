package com.safeanchor;

import net.minecraft.block.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.RaycastContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.*;

/** Mini-Baritone: tìm block mục tiêu, dò đường (Dijkstra, đào xuyên khi cần), né lava/lửa/xương rồng/magma, đi và đào. */
public class AutoMine {
    static final Direction[] H = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};
    static final Set<Block> targets = new HashSet<>();
    static int sig;
    static BlockPos goal;
    static List<BlockPos> path = new ArrayList<>();
    static int scanCd, stuck, pause;
    static BlockPos lastPos;
    static float lastHp;
    static boolean held;
    static BlockPos mining;

    // ----- chế độ đào theo VÙNG (FreeDig): đào mọi block trong hộp từ tầng trên xuống -----
    public static BlockPos areaMin, areaMax;
    public static int layerY = Integer.MIN_VALUE;                 // tầng đang đào (để vẽ)
    public static boolean areaActive() { return areaMin != null; }
    public static void startArea(BlockPos a, BlockPos b) {
        areaMin = a; areaMax = b; goal = null; path.clear(); layerY = b.getY();
        Config.I.mineOn = true; Config.save();
    }
    public static void stopArea(MinecraftClient mc) {
        if (areaMin == null) return;
        areaMin = areaMax = null; layerY = Integer.MIN_VALUE;
        Config.I.mineOn = false; Config.save();
        stop(mc);
    }
    static boolean inArea(BlockPos p) {
        return areaMin != null && p.getX() >= areaMin.getX() && p.getX() <= areaMax.getX() && p.getY() >= areaMin.getY() && p.getY() <= areaMax.getY()
                && p.getZ() >= areaMin.getZ() && p.getZ() <= areaMax.getZ();
    }
    /** Block có phải mục tiêu không: chế độ vùng = mọi block đào được trong vùng; bình thường = block trong danh sách quặng. */
    static boolean isTarget(World w, BlockPos p) {
        var st = w.getBlockState(p);
        if (areaMin != null) return inArea(p) && !st.isAir() && st.getFluidState().isEmpty() && st.getHardness(w, p) >= 0 && !st.hasBlockEntity() && !danger(w, p);
        return targets.contains(st.getBlock());
    }

    public static void toggle(MinecraftClient mc) {
        Config.I.mineOn = !Config.I.mineOn; Config.save();
        if (!Config.I.mineOn) stop(mc);
        Util.msg("Tự đào: " + (Config.I.mineOn ? "§aBẬT" : "§cTẮT"));
    }

    static void stop(MinecraftClient mc) {
        if (held) { mc.options.forwardKey.setPressed(false); mc.options.jumpKey.setPressed(false); held = false; }
        goal = null; path.clear(); mining = null;
    }

    // ---------- kiểm tra block ----------
    static boolean lava(World w, BlockPos p) { FluidState f = w.getFluidState(p); return !f.isEmpty() && f.isIn(FluidTags.LAVA); }
    static boolean danger(World w, BlockPos p) {
        Block b = w.getBlockState(p).getBlock();
        return lava(w, p) || b == Blocks.FIRE || b == Blocks.SOUL_FIRE || b == Blocks.MAGMA_BLOCK || b == Blocks.CACTUS
                || b == Blocks.SWEET_BERRY_BUSH || b == Blocks.COBWEB || b == Blocks.POWDER_SNOW || b == Blocks.CAMPFIRE
                || b == Blocks.SOUL_CAMPFIRE || b == Blocks.WITHER_ROSE || b == Blocks.POINTED_DRIPSTONE;
    }
    static boolean nearLava(World w, BlockPos p) {
        for (Direction d : Direction.values()) if (lava(w, p.offset(d))) return true;
        return false;
    }
    static boolean passable(World w, BlockPos p) {
        var s = w.getBlockState(p);
        return s.getCollisionShape(w, p).isEmpty() && s.getFluidState().isEmpty() && !danger(w, p);
    }
    static boolean floor(World w, BlockPos p) {
        var s = w.getBlockState(p);
        return !s.getCollisionShape(w, p).isEmpty() && s.getFluidState().isEmpty() && !danger(w, p);
    }
    static boolean breakable(World w, BlockPos p) {
        var s = w.getBlockState(p);
        if (s.isAir() || !s.getFluidState().isEmpty() || danger(w, p) || s.hasBlockEntity()) return false;
        if (s.getHardness(w, p) < 0) return false;
        return !nearLava(w, p) && w.getFluidState(p.up()).isEmpty();
    }
    /** chi phí để dọn ô: 0 trống, >0 phải đào, <0 không được */
    static double clearCost(World w, BlockPos p) {
        if (passable(w, p)) return 0;
        if (breakable(w, p)) return 3 + w.getBlockState(p).getHardness(w, p);
        return -1;
    }

    record Node(BlockPos pos, double g, double f) {}

    static List<BlockPos> findPath(World w, BlockPos start, BlockPos target, int limit) {
        PriorityQueue<Node> open = new PriorityQueue<>(Comparator.comparingDouble(Node::f));
        Map<BlockPos, Double> best = new HashMap<>();
        Map<BlockPos, BlockPos> from = new HashMap<>();
        open.add(new Node(start, 0, 0)); best.put(start, 0.0);
        int n = 0;
        while (!open.isEmpty() && n++ < limit) {
            Node cur = open.poll();
            BlockPos cp = cur.pos;
            if (cur.g > best.getOrDefault(cp, 1e18)) continue;
            // đích: block mục tiêu kề chân hoặc đầu
            if (adjacent(cp, target) || adjacent(cp.up(), target)) {
                LinkedList<BlockPos> r = new LinkedList<>();
                for (BlockPos q = cp; q != null && !q.equals(start); q = from.get(q)) r.addFirst(q);
                return r;
            }
            for (Direction d : H) for (int dy = -1; dy <= 1; dy++) {
                BlockPos nf = cp.offset(d).up(dy);
                if (Math.abs(nf.getX() - start.getX()) > 40 || Math.abs(nf.getZ() - start.getZ()) > 40) continue;
                if (!floor(w, nf.down())) continue;
                if (nearLava(w, nf) || nearLava(w, nf.up()) || nearLava(w, nf.down())) continue;
                double cost = 1;
                BlockPos[] cells = dy == 1 ? new BlockPos[]{cp.up(2), nf, nf.up()} : dy == -1 ? new BlockPos[]{nf.up(), nf} : new BlockPos[]{nf, nf.up()};
                boolean ok = true;
                for (BlockPos cell : cells) {
                    if (cell.equals(target)) { cost += 2; continue; }
                    double cc = clearCost(w, cell);
                    if (cc < 0) { ok = false; break; }
                    cost += cc;
                }
                if (!ok) continue;
                double g = cur.g + cost;
                if (g < best.getOrDefault(nf, 1e18)) {
                    best.put(nf, g); from.put(nf, cp);
                    double hh = Math.sqrt(nf.getSquaredDistance(target)) * 1.2;
                    open.add(new Node(nf, g, g + hh));
                }
            }
        }
        return null;
    }
    static boolean adjacent(BlockPos a, BlockPos t) { return a.getManhattanDistance(t) == 1; }

    // ---------- chọn mục tiêu ----------
    static void rebuild() {
        targets.clear();
        for (String s : Config.I.mineList) {
            Identifier i = Identifier.tryParse(s.contains(":") ? s : "minecraft:" + s);
            if (i == null) continue;
            Block b = Registries.BLOCK.get(i);
            if (b != Blocks.AIR) targets.add(b);
        }
    }

    /** Chế độ vùng: tầng cao nhất còn block (ưu tiên khu quanh người chơi), chọn block gần nhất trong tầng đó. */
    static BlockPos findAreaTarget(MinecraftClient mc) {
        var w = mc.world; BlockPos pc = mc.player.getBlockPos();
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int pass = 0; pass < 2; pass++) {
            int x0 = pass == 0 ? Math.max(areaMin.getX(), pc.getX() - 12) : areaMin.getX(), x1 = pass == 0 ? Math.min(areaMax.getX(), pc.getX() + 12) : areaMax.getX();
            int z0 = pass == 0 ? Math.max(areaMin.getZ(), pc.getZ() - 12) : areaMin.getZ(), z1 = pass == 0 ? Math.min(areaMax.getZ(), pc.getZ() + 12) : areaMax.getZ();
            for (int y = areaMax.getY(); y >= areaMin.getY(); y--) {
                BlockPos best = null; double bd = 1e18;
                for (int x = x0; x <= x1; x++) for (int z = z0; z <= z1; z++) {
                    m.set(x, y, z);
                    if (!isTarget(w, m) || nearLava(w, m)) continue;
                    double d = (x - pc.getX()) * (double) (x - pc.getX()) + (z - pc.getZ()) * (double) (z - pc.getZ()) + Math.abs(y - pc.getY()) * 2.0;
                    if (d < bd) { bd = d; best = m.toImmutable(); }
                }
                if (best != null) { layerY = y; return best; }
            }
        }
        return null;
    }

    /** Block mục tiêu trong tầm với (và nhìn thấy): đập hết quanh đây trước khi đi chỗ khác (cả cây, cả cả vùng đào). Nếu có lá / block che thì đập block che. */
    static BlockPos nearTarget(MinecraftClient mc) {
        var p = mc.player; var w = mc.world;
        Vec3d eye = p.getEyePos(); BlockPos pc = p.getBlockPos();
        List<BlockPos> cand = new ArrayList<>();
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -5; dx <= 5; dx++) for (int dy = -4; dy <= 6; dy++) for (int dz = -5; dz <= 5; dz++) {
            m.set(pc.getX() + dx, pc.getY() + dy, pc.getZ() + dz);
            if (!isTarget(w, m)) continue;
            if (eye.squaredDistanceTo(Vec3d.ofCenter(m)) > 4.4 * 4.4 || nearLava(w, m)) continue;
            cand.add(m.toImmutable());
        }
        if (cand.isEmpty()) return null;
        boolean area = areaMin != null;
        cand.sort((a, b) -> area && a.getY() != b.getY() ? Integer.compare(b.getY(), a.getY())
                : Double.compare(eye.squaredDistanceTo(Vec3d.ofCenter(a)), eye.squaredDistanceTo(Vec3d.ofCenter(b))));
        for (BlockPos q : cand) {
            var hit = w.raycast(new RaycastContext(eye, Vec3d.ofCenter(q), RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, p));
            if (hit.getType() != HitResult.Type.BLOCK || hit.getBlockPos().equals(q)) { if (area) layerY = q.getY(); return q; }
            BlockPos bl = hit.getBlockPos();
            if (breakable(w, bl) && (!area || inArea(bl))) return bl;
        }
        return null;
    }

    static BlockPos findTarget(MinecraftClient mc) {
        if (areaMin != null) return findAreaTarget(mc);
        int r = (int) Config.I.mineRange;
        BlockPos pc = mc.player.getBlockPos(), best = null; double bd = 1e18;
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -r; dx <= r; dx++) for (int dy = -r; dy <= r; dy++) for (int dz = -r; dz <= r; dz++) {
            m.set(pc.getX() + dx, pc.getY() + dy, pc.getZ() + dz);
            if (!targets.contains(mc.world.getBlockState(m).getBlock())) continue;
            double d = dx * dx + dy * dy * 1.5 + dz * dz;
            if (d < bd && !nearLava(mc.world, m)) { bd = d; best = m.toImmutable(); }
        }
        return best;
    }

    static boolean pick(ItemStack s) { return s.isIn(ItemTags.PICKAXES); }

    static boolean mine(MinecraftClient mc, BlockPos cell) {
        var p = mc.player;
        Vec3d c = Vec3d.ofCenter(cell);
        if (p.getEyePos().distanceTo(c) > 4.6) return false;
        Util.selectBestTool(mc.world.getBlockState(cell));          // tự cầm đúng dụng cụ (rìu cho gỗ, xẻng cho đất, cuốc cho đá...)
        Util.aim(p, c);
        Vec3d d = c.subtract(p.getEyePos());
        mc.interactionManager.updateBlockBreakingProgress(cell, Direction.getFacing(-d.x, -d.y, -d.z));
        p.swingHand(Hand.MAIN_HAND);
        return true;
    }

    public static void tick(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player; var w = mc.world;
        if (!c.mineOn || !c.enabled || p == null || w == null || mc.interactionManager == null || mc.currentScreen != null) { if (held) stop(mc); return; }
        if (pause > 0) { pause--; return; }
        // (đã bỏ: dừng khi dính damage) - né lava/lửa/xương rồng đã làm ở bước dò đường
        int s = Objects.hash(c.mineList); if (s != sig) { sig = s; rebuild(); goal = null; path.clear(); }
        if (targets.isEmpty() && areaMin == null) return;

        if (mining != null && w.getBlockState(mining).isAir()) { mining = null; scanCd = 0; }     // vừa đào xong -> chọn tiếp ngay
        if (goal != null && !isTarget(w, goal)) { goal = null; path.clear(); }
        BlockPos near = nearTarget(mc);                       // đập hết block trong tầm trước (cả cây) rồi mới đi chỗ khác
        if (near != null) {
            mc.options.forwardKey.setPressed(false); mc.options.jumpKey.setPressed(false); held = false; stuck = 0;
            if (mine(mc, near)) { mining = near; return; }
        }
        if (goal == null) {
            if (scanCd-- > 0) return;
            scanCd = 30;
            goal = findTarget(mc);
            if (goal == null) {
                if (areaMin != null) { Util.msg("Đào xong vùng!"); stopArea(mc); return; }
                stop(mc); return;
            }
            var r = findPath(w, p.getBlockPos(), goal, 9000);
            if (r == null) { Util.warn("Không tìm được đường tới block"); goal = null; return; }
            path = new ArrayList<>(r); stuck = 0;
        }

        // chống kẹt
        if (p.getBlockPos().equals(lastPos)) { if (++stuck > 80) { stuck = 0; goal = null; path.clear(); return; } } else { stuck = 0; lastPos = p.getBlockPos(); }

        if (path.isEmpty()) {          // đã kề block mục tiêu -> đào
            mc.options.forwardKey.setPressed(false); mc.options.jumpKey.setPressed(false); held = false;
            mine(mc, goal); return;
        }
        BlockPos next = path.get(0), feet = p.getBlockPos();
        if (feet.equals(next)) { path.remove(0); return; }
        // dọn chướng ngại ở ô kế tiếp
        List<BlockPos> need = new ArrayList<>();
        if (next.getY() > feet.getY()) need.add(feet.up(2));
        need.add(next.up()); need.add(next);
        for (BlockPos cell : need) {
            if (cell.equals(goal)) continue;
            if (!passable(w, cell)) {
                mc.options.forwardKey.setPressed(false); held = false;
                if (!breakable(w, cell) || !mine(mc, cell)) { goal = null; path.clear(); }
                return;
            }
        }
        // đi tới ô kế tiếp
        Vec3d to = Vec3d.ofBottomCenter(next);
        Util.aim(p, new Vec3d(to.x, p.getEyeY(), to.z));
        mc.options.forwardKey.setPressed(true); held = true;
        boolean jump = next.getY() > feet.getY() || (p.horizontalCollision && p.isOnGround());
        mc.options.jumpKey.setPressed(jump);
        if (Math.hypot(p.getX() - to.x, p.getZ() - to.z) < 0.3 && Math.abs(p.getY() - next.getY()) < 0.8) path.remove(0);
    }
}

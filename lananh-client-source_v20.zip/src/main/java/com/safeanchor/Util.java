package com.safeanchor;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInputC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;

import java.util.function.Predicate;

public final class Util {
    static final MinecraftClient mc = MinecraftClient.getInstance();
    private static long lastWarn = 0;
    /** true khi chính client đang tự tương tác (để chặn-mở-rương / Safe Anchor không can thiệp). */
    public static boolean bot;

    public static ActionResult interact(ClientPlayerEntity p, Hand h, BlockHitResult r) {
        boolean old = bot; bot = true;
        try { return mc.interactionManager.interactBlock(p, h, r); } finally { bot = old; }
    }

    public static void msg(String s) { if (mc.player != null) mc.player.sendMessage(Text.literal("§d[Lan Anh] §f" + s), true); }
    public static void warn(String s) { long n = System.currentTimeMillis(); if (n - lastWarn > 2000) { lastWarn = n; msg("§c" + s); } }

    /** Tiêu đề to, đậm, màu hồng. */
    public static void title(DrawContext ctx, int x, int y, float scale) {
        var m = ctx.getMatrices();
        m.push(); m.translate(x, y, 0); m.scale(scale, scale, 1f);
        ctx.drawText(mc.textRenderer, Text.literal("LAN ANH CLIENT v2.22").setStyle(Style.EMPTY.withBold(true).withColor(0xFF69B4)), 0, 0, 0xFFFF69B4, true);
        m.pop();
    }

    /** Màu cầu vồng chạy theo thời gian (rgb, không alpha). */
    public static int chroma(double offset) {
        float h = (float) ((System.currentTimeMillis() % 6000) / 6000.0 + offset);
        return java.awt.Color.HSBtoRGB(h, 0.7f, 1f) & 0xFFFFFF;
    }

    public static int screenSlot(int invIndex) { return invIndex < 9 ? 36 + invIndex : invIndex; }
    public static void click(int screenSlot, int button, SlotActionType type) {
        mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, screenSlot, button, type, mc.player);
    }

    public static boolean select(int hotbar) {
        if (hotbar < 0 || hotbar > 8) return false;
        mc.player.getInventory().selectedSlot = hotbar; return true;
    }

    /** Chọn item vào tay: tìm hotbar trước, không có thì kéo từ túi vào ô phụ. */
    public static boolean selectItem(Predicate<ItemStack> pred) {
        var inv = mc.player.getInventory();
        for (int i = 0; i < 9; i++) if (pred.test(inv.getStack(i))) { inv.selectedSlot = i; return true; }
        for (int i = 9; i < 36; i++) if (pred.test(inv.getStack(i))) {
            int spare = pickSpare();
            click(screenSlot(i), spare, SlotActionType.SWAP);
            inv.selectedSlot = spare; return true;
        }
        return false;
    }
    /** Cầm dụng cụ đào nhanh nhất với block này (rìu / xẻng / cuốc / kéo...). */
    public static void selectBestTool(net.minecraft.block.BlockState st) {
        var inv = mc.player.getInventory();
        float bs = inv.getStack(inv.selectedSlot).getMiningSpeedMultiplier(st);
        ItemStack best = null;
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getStack(i);
            if (s.isEmpty() || (s.getMaxDamage() > 0 && s.getDamage() >= s.getMaxDamage() - 1)) continue;
            float sp = s.getMiningSpeedMultiplier(st);
            if (sp > bs + 0.01f) { bs = sp; best = s; }
        }
        if (best != null) { final ItemStack target = best; selectItem(x -> x == target); }
    }

    static boolean important(ItemStack s) {
        return s.isOf(Items.MACE) || s.isOf(Items.TOTEM_OF_UNDYING) || s.isOf(Items.RESPAWN_ANCHOR) || s.isOf(Items.GLOWSTONE)
                || s.isOf(Items.END_CRYSTAL) || s.isOf(Items.FIREWORK_ROCKET) || s.isOf(Items.OBSIDIAN) || s.isOf(Items.ENDER_PEARL)
                || s.isOf(Items.ELYTRA) || s.isOf(Items.GOLDEN_APPLE) || s.isOf(Items.ENCHANTED_GOLDEN_APPLE);
    }
    /** Ô hotbar để đổi đồ từ túi: ưu tiên ô trống, không đè lên mace/totem/anchor... */
    static int pickSpare() {
        var inv = mc.player.getInventory();
        for (int i = 8; i >= 0; i--) if (inv.getStack(i).isEmpty()) return i;
        int pref = Math.max(0, Math.min(8, Config.I.spareSlot - 1));
        if (!important(inv.getStack(pref))) return pref;
        for (int i = 8; i >= 0; i--) if (!important(inv.getStack(i))) return i;
        return pref;
    }
    public static boolean has(Predicate<ItemStack> pred) {
        var inv = mc.player.getInventory();
        for (int i = 0; i < 36; i++) if (pred.test(inv.getStack(i))) return true;
        return false;
    }

    public static boolean isChestplate(ItemStack s) {
        if (s.isEmpty() || s.isOf(Items.ELYTRA)) return false;
        EquippableComponent e = s.get(DataComponentTypes.EQUIPPABLE);
        return e != null && e.slot() == EquipmentSlot.CHEST;
    }
    public static boolean isElytra(ItemStack s) { return s.isOf(Items.ELYTRA); }
    public static boolean chestIs(Predicate<ItemStack> p) { return p.test(mc.player.getEquippedStack(EquipmentSlot.CHEST)); }

    /** Đổi áo/cánh (3 lần click pickup – ổn định hơn SWAP). allowNone: nếu không có đồ thay thì tháo ra túi. */
    public static boolean equipChest(Predicate<ItemStack> want, boolean allowNone) {
        if (chestIs(want)) return true;
        var inv = mc.player.getInventory();
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getStack(i);
            if (!s.isEmpty() && want.test(s)) {
                int slot = screenSlot(i);
                click(slot, 0, SlotActionType.PICKUP);
                click(6, 0, SlotActionType.PICKUP);
                click(slot, 0, SlotActionType.PICKUP);
                return true;
            }
        }
        if (allowNone && !mc.player.getEquippedStack(EquipmentSlot.CHEST).isEmpty()) {
            click(6, 0, SlotActionType.QUICK_MOVE); return true;
        }
        return false;
    }

    public static void autoTotem() {
        Config c = Config.I;
        if (!c.autoTotem || mc.player == null || mc.currentScreen != null) return;
        if (mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        var inv = mc.player.getInventory();
        int pref = c.totemSlot - 1;
        int from = -1;
        if (pref >= 0 && pref < 9 && inv.getStack(pref).isOf(Items.TOTEM_OF_UNDYING)) from = pref;
        else for (int i = 0; i < 36; i++) if (inv.getStack(i).isOf(Items.TOTEM_OF_UNDYING)) { from = i; break; }
        if (from >= 0) click(screenSlot(from), 40, SlotActionType.SWAP);
    }

    static final java.util.Random PACE_RND = new java.util.Random();
    /** Chế độ Safe / Risk / Unsafe: Safe chậm hơn + lệch ngẫu nhiên như người, Risk giữ nguyên, Unsafe không chờ. */
    public static int pace(int ticks) {
        return switch (Config.I.mode) { case 0 -> Math.max(1, ticks * 2) + PACE_RND.nextInt(2); case 2 -> 0; default -> ticks; };
    }
    /** Số thao tác tối đa mỗi tick theo chế độ (Safe 1, Risk tối đa 4, Unsafe không giới hạn). */
    public static int cap(int n) { return switch (Config.I.mode) { case 0 -> 1; case 2 -> n; default -> Math.min(n, 4); }; }

    public static PlayerEntity nearestEnemy(double range) {
        PlayerEntity best = null; double bd = range * range;
        for (PlayerEntity o : mc.world.getPlayers()) {
            if (o == mc.player || o.isSpectator() || !o.isAlive()) continue;
            double d = o.squaredDistanceTo(mc.player);
            if (d < bd) { bd = d; best = o; }
        }
        return best;
    }

    public static double distToBox(Vec3d p, Box b) {
        double dx = Math.max(Math.max(b.minX - p.x, 0), p.x - b.maxX);
        double dy = Math.max(Math.max(b.minY - p.y, 0), p.y - b.maxY);
        double dz = Math.max(Math.max(b.minZ - p.z, 0), p.z - b.maxZ);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    public static void aim(ClientPlayerEntity p, Vec3d to) {
        Vec3d e = p.getEyePos();
        double dx = to.x - e.x, dy = to.y - e.y, dz = to.z - e.z;
        p.setYaw((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0));
        p.setPitch((float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz))));
    }

    public static void sendLook(float yaw, float pitch) {
        mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch, mc.player.isOnGround(), mc.player.horizontalCollision));
    }
    public static void sendSneak(boolean sneak) {
        PlayerInput o = mc.player.input.playerInput;
        mc.player.networkHandler.sendPacket(new PlayerInputC2SPacket(new PlayerInput(o.forward(), o.backward(), o.left(), o.right(), o.jump(), sneak, o.sprint())));
    }
    public static void offhandSwapPacket() {
        mc.player.networkHandler.sendPacket(new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.SWAP_ITEM_WITH_OFFHAND, BlockPos.ORIGIN, Direction.DOWN));
    }

    /** Đặt block `item` vào ô `pos` (không quan tâm hướng). */
    /** Đặt block có XOAY ĐẦU thật tới đúng mặt block (gửi packet góc nhìn) - dành cho server có anti-cheat như Bedwars. */
    public static boolean placeBlockLook(BlockPos pos, Item item) {
        var p = mc.player; var w = mc.world;
        if (!w.getBlockState(pos).isReplaceable()) return false;
        Vec3d eye = p.getEyePos();
        for (Direction d : Direction.values()) {
            BlockPos nb = pos.offset(d);
            BlockState ns = w.getBlockState(nb);
            if (ns.isAir() || ns.isReplaceable() || !ns.getFluidState().isEmpty()) continue;
            Direction face = d.getOpposite();
            Vec3d target = Vec3d.ofCenter(nb).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
            if (eye.distanceTo(target) > Config.I.reach) continue;
            double dx = target.x - eye.x, dy = target.y - eye.y, dz = target.z - eye.z;
            float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
            float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));
            Vec3d dir = Vec3d.fromPolar(pitch, yaw);
            BlockHitResult rc = w.raycast(new RaycastContext(eye, eye.add(dir.multiply(Config.I.reach + 1)),
                    RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, p));
            if (rc.getType() != net.minecraft.util.hit.HitResult.Type.BLOCK || !rc.getBlockPos().equals(nb) || rc.getSide() != face) continue;
            if (!selectItem(s -> s.isOf(item))) return false;
            float oy = p.getYaw(), op = p.getPitch();
            sendLook(yaw, pitch);
            ActionResult r = interact(p, Hand.MAIN_HAND, rc);
            if (r.isAccepted()) p.swingHand(Hand.MAIN_HAND);
            sendLook(oy, op);
            if (r.isAccepted()) return true;
        }
        return false;
    }

    public static boolean placeBlock(BlockPos pos, Item item) {
        var p = mc.player; var w = mc.world;
        if (!w.getBlockState(pos).isReplaceable()) return false;
        for (Direction d : Direction.values()) {
            BlockPos nb = pos.offset(d);
            BlockState ns = w.getBlockState(nb);
            if (ns.isAir() || ns.isReplaceable() || !ns.getFluidState().isEmpty()) continue;
            Direction face = d.getOpposite();
            Vec3d hit = Vec3d.ofCenter(nb).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
            if (p.getEyePos().distanceTo(hit) > Config.I.reach) continue;
            if (!selectItem(s -> s.isOf(item))) return false;
            ActionResult r = interact(p, Hand.MAIN_HAND, new BlockHitResult(hit, face, nb, false));
            if (r.isAccepted()) { p.swingHand(Hand.MAIN_HAND); return true; }
        }
        return false;
    }

    public static boolean useOnBlock(BlockPos pos, Direction face) {
        Vec3d hit = Vec3d.ofCenter(pos).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
        ActionResult r = interact(mc.player, Hand.MAIN_HAND, new BlockHitResult(hit, face, pos, false));
        if (r.isAccepted()) mc.player.swingHand(Hand.MAIN_HAND);
        return r.isAccepted();
    }

    public static double selfDamage(PlayerEntity p, Vec3d pos) {
        double d = p.getPos().distanceTo(pos) / 12.0;
        if (d > 1) return 0;
        double imp = 1 - d;
        double dmg = (imp * imp + imp) / 2.0 * 7.0 * 12.0 + 1.0;
        return dmg * (1 - Math.min(20, p.getArmor()) / 25.0);
    }

    /** Dự đoán điểm rơi ender pearl của người khác. */
    public static Vec3d pearlLanding() {
        for (var e : mc.world.getEntities()) {
            if (!(e instanceof EnderPearlEntity pe)) continue;
            if (pe.getOwner() == mc.player || pe.squaredDistanceTo(mc.player) > 40 * 40) continue;
            Vec3d pos = pe.getPos(), vel = pe.getVelocity();
            for (int i = 0; i < 120; i++) {
                Vec3d next = pos.add(vel);
                var hit = mc.world.raycast(new RaycastContext(pos, next, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, pe));
                if (hit.getType() == net.minecraft.util.hit.HitResult.Type.BLOCK) return hit.getPos();
                pos = next; vel = vel.multiply(0.99).add(0, -0.03, 0);
            }
        }
        return null;
    }

    /** Các block mà mọi ender pearl đang bay (kể cả của mình) sẽ rơi xuống. */
    public static java.util.List<net.minecraft.util.math.BlockPos> pearlBlocks() {
        java.util.List<net.minecraft.util.math.BlockPos> out = new java.util.ArrayList<>();
        for (var e : mc.world.getEntities()) {
            if (!(e instanceof EnderPearlEntity pe)) continue;
            Vec3d pos = pe.getPos(), vel = pe.getVelocity();
            for (int i = 0; i < 120; i++) {
                Vec3d next = pos.add(vel);
                var hit = mc.world.raycast(new RaycastContext(pos, next, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, pe));
                if (hit.getType() == net.minecraft.util.hit.HitResult.Type.BLOCK) { out.add(hit.getBlockPos()); break; }
                pos = next; vel = vel.multiply(0.99).add(0, -0.03, 0);
            }
        }
        return out;
    }
}
